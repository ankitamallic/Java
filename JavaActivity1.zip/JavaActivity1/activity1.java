package JavaActivity1;

public class activity1 {

    public static void main(String[] args) {
        car toyota = new car();
        toyota.make = 2014;
        toyota.color = "Black";
        toyota.transmission = "Manual";
    
        //class method
        toyota.displayCharacterstics();
        toyota.accelerate();
        toyota.brake();
    }

}