package JavaActivity1;

    public class car {
   
    String color;
    int make;
    String transmission;
    int tyres;
    int doors;
	
    //Constructor
    car() {
	tyres = 4;
	doors = 4;
    }

    //Class Methods
    	public void displayCharacterstics(){
    		
    		System.out.println("The Car is: " + color);
    		System.out.println("Transmission type of the car is : " + transmission);
    		System.out.println("Car was manufactured on : " + make);
    		System.out.println("Number of tyres on the car is : " + tyres);
    		System.out.println("Number of doors on the car is : " + doors);
    		
         }

    	public void accelerate() {
    		System.out.println("Car is moving forward.");
         
    	}
	
    	public void brake() {
    		System.out.println("Car has stopped.");
    }
}